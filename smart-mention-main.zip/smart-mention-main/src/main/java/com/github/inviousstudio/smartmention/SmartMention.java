package com.github.inviousstudio.smartmention;

import org.bukkit.plugin.java.JavaPlugin;

public final class SmartMention extends JavaPlugin {

    @Override
    public void onEnable() {

    }

    @Override
    public void onDisable() {

    }
}
